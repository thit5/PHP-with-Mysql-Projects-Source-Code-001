<div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>AVMS 2018. All rights reserved.</p>
                                </div>
                            </div>
                        </div>